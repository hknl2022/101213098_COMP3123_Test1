const mixedArray = ['PIZZA', 10, true, 25, false, 'Wings'];

const lowerCaseWords = (mixedArray) => {

    return new Promise((resolve, reject) => {
        let stringArray = mixedArray.filter((item) => {
            return typeof item === 'string';
        });
        if (stringArray.length > 0) {
            resolve(stringArray.map((item) => {
                return item.toLowerCase();
            }));
        } else {
            reject('No string in array');
        }
    });
}

lowerCaseWords(mixedArray)
    .then((result) => {

        console.log(result);
    })