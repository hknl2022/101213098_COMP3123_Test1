const fs = require('fs');
const path = require('path');

if (fs.existsSync("Logs")) {
    
    fs.readdirSync("Logs").forEach(file => {

        fs.unlink(path.join("Logs", file), (err) => {
            if (err) throw err;
        });
        console.log(`deleting files... `);
        }
    );
    fs.readdirSync("Logs")
}